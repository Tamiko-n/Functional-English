const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;
const cors = require('cors');
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/DisasterRelief');

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// Define a schema for your form data
const formSchema = new mongoose.Schema({
    name: String,
    phoneNumber: Number,
    city: String,
    province: String,
    medicalSupply: String,
    quantity: Number,
    location: String
});

const Form = mongoose.model('Form', formSchema);

// Handle form submissions
app.post('/submit-form', async (req, res) => {
    const { name, phoneNumber, city, province, medicalSupply, quantity, location } = req.body;
    const newForm = new Form({
        name,
        phoneNumber,
        city,
        province,
        medicalSupply,
        quantity,
        location
    });

    try {
        await newForm.save();
        res.send('Form submitted successfully!');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error saving form data');
    }
});

app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});
